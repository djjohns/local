//
//  AppDelegate.h
//  Theremin
//
//  Created by Bill Weinman on 2014-08-21.
//  Copyright (c) 2014 Bill Weinman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

