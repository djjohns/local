//
//  ViewController.m
//  Theremin-iOS
//
//  Created by Bill Weinman on 2014-08-14.
//  Copyright (c) 2014 Bill Weinman. All rights reserved.
//

#import "ViewController.h"

#pragma mark Functions

OSStatus RenderTone( void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData) {
    // Get the tone parameters out of the view controller
    ViewController *viewController = (__bridge ViewController *)inRefCon;
    
    double theta = viewController->theta;
    double theta_increment = 2.0 * M_PI * viewController->frequency / viewController->sampleRate;
    
    // logarithmic volume scale -- more intuitive
    static double e_const = 0.0;
    if (e_const == 0.0) e_const = exp(1); // calculate e -- only do this once
    
    double amplitude = (pow(e_const, viewController->volume / 100) -1) / (e_const - 1);
    
    // This is a mono tone generator so we only need the first buffer
    const int channel = 0;
    Float32 *buffer = (Float32 *)ioData->mBuffers[channel].mData;
    
    // Generate the samples
    for (UInt32 frame = 0; frame < inNumberFrames; frame++)
    {
        buffer[frame] = sin(theta) * amplitude;
        
        theta += theta_increment;
        if (theta > 2.0 * M_PI)
        {
            theta -= 2.0 * M_PI;
        }
    }
    
    // Store the theta back in the view controller
    viewController->theta = theta;
    
    return noErr;
}

@implementation ViewController {
    IBOutlet UISlider *_frequencySlider;
    IBOutlet UISlider *_volumeSlider;
    IBOutlet UIButton *_playButton;
    IBOutlet UILabel *_statusLabel;
    IBOutlet UIView * _topView;
    IBOutlet UIView * _innerView;
    
    AudioComponentInstance _toneUnit;
    NSTimer * _dispTimer;
    
    int offsetPanWidth;
    int offsetPanHeight;
    double view_x;
    double view_y;
}

#pragma mark IB actions

- (IBAction)volumeSliderChanged:(UISlider *)slider
{
    volume = slider.value;
}

- (IBAction)frequencySliderChanged:(UISlider *)slider
{
    frequency = slider.value;
}

- (IBAction)togglePlay:(UIButton *)selectedButton
{
    if (_toneUnit)
    {
        [self toneStop];
    }
    else
    {
        [self createToneUnit];
        
        // Stop changing parameters on the unit
        int err = AudioUnitInitialize(_toneUnit);
        NSAssert1(err == noErr, @"Error initializing unit: %d", err);
        
        // Start playback
        err = AudioOutputUnitStart(_toneUnit);
        NSAssert1(err == noErr, @"Error starting unit: %d", err);
        
        [selectedButton setTitle:@"Stop" forState:UIControlStateNormal];
    }
}

- (void)panMethod:(UIPanGestureRecognizer *)sender {
    if(sender.numberOfTouches == 1) {
        view_y = (offsetPanHeight - [sender locationInView:_innerView].y) / offsetPanHeight;
        view_x = [sender locationInView:_innerView].x / offsetPanWidth;
        if(view_y < 0 || view_y > 1.0 || view_x < 0 || view_x > 1.0 ) return;
        
        volume = view_x * 100.0;
        frequency = ( view_y * 3960.0 ) + 40.0;
    }
    //    [self dispStatus];
}

#pragma mark View Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIPanGestureRecognizer * pan =[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panMethod:)];
    pan.maximumNumberOfTouches = 1;
    [pan setDelegate:self];
    [_innerView addGestureRecognizer:pan];
    
    _frequencySlider.value = 440.0;
    _volumeSlider.value = 25.0;
    
    [self frequencySliderChanged:_frequencySlider];
    [self volumeSliderChanged:_volumeSlider];
    sampleRate = 44100;
    
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive:true error:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(toneInterruptionListener:) name:AVAudioSessionInterruptionNotification object:[AVAudioSession sharedInstance]];
    
    _dispTimer = [NSTimer scheduledTimerWithTimeInterval:_timerValue target:self selector:@selector(dispTimer:) userInfo:nil repeats:true];
}

- (void)viewDidUnload {
    _statusLabel.text = @"";
    
    [_dispTimer invalidate];
    _dispTimer = nil;
    
    [[AVAudioSession sharedInstance] setActive:false error:nil];
}

- (void) viewDidLayoutSubviews {
    [self setPanOffset];
}

- (void) dispTimer: (NSTimer *) timer {
    [self dispStatus];
}

#pragma mark Tone Unit

- (void)toneStop
{
    AudioOutputUnitStop(_toneUnit);
    AudioUnitUninitialize(_toneUnit);
    AudioComponentInstanceDispose(_toneUnit);
    _toneUnit = nil;
    
    [_playButton setTitle:@"Play" forState:UIControlStateNormal];
}

- (void)createToneUnit {
    // Configure the search parameters to find the default playback output unit
    // (called the kAudioUnitSubType_RemoteIO on iOS or
    //   kAudioUnitSubType_DefaultOutput on Mac OS X)
    AudioComponentDescription defaultOutputDescription;
    defaultOutputDescription.componentType = kAudioUnitType_Output;
    defaultOutputDescription.componentSubType = kAudioUnitSubType_RemoteIO;
    defaultOutputDescription.componentManufacturer = kAudioUnitManufacturer_Apple;
    defaultOutputDescription.componentFlags = 0;
    defaultOutputDescription.componentFlagsMask = 0;
    
    // Get the default playback output unit
    AudioComponent defaultOutput = AudioComponentFindNext(NULL, &defaultOutputDescription);
    NSAssert(defaultOutput, @"Can't find default output");
    
    // Create a new unit based on this that we'll use for output
    int err = AudioComponentInstanceNew(defaultOutput, &_toneUnit);
    NSAssert1(_toneUnit, @"Error creating unit: %d", err);
    
    // Set our tone rendering function on the unit
    AURenderCallbackStruct input;
    input.inputProc = RenderTone;
    input.inputProcRefCon = (__bridge void *)(self);
    err = AudioUnitSetProperty(_toneUnit, kAudioUnitProperty_SetRenderCallback, kAudioUnitScope_Input, 0, &input, sizeof(input));
    NSAssert1(err == noErr, @"Error setting callback: %d", err);
    
    // Set the format to 32 bit, single channel, floating point, linear PCM
    const int four_bytes_per_float = 4;
    const int eight_bits_per_byte = 8;
    AudioStreamBasicDescription streamFormat;
    streamFormat.mSampleRate = sampleRate;
    streamFormat.mFormatID = kAudioFormatLinearPCM;
    streamFormat.mFormatFlags = kAudioFormatFlagsNativeFloatPacked | kAudioFormatFlagIsNonInterleaved;
    streamFormat.mBytesPerPacket = four_bytes_per_float;
    streamFormat.mFramesPerPacket = 1;
    streamFormat.mBytesPerFrame = four_bytes_per_float;
    streamFormat.mChannelsPerFrame = 1;
    streamFormat.mBitsPerChannel = four_bytes_per_float * eight_bits_per_byte;
    err = AudioUnitSetProperty (_toneUnit, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input, 0, &streamFormat, sizeof(AudioStreamBasicDescription));
    NSAssert1(err == noErr, @"Error setting stream format: %d", err);
}

- (void) toneInterruptionListener: (NSNotification *) nso {
    [self toneStop];
}

#pragma mark utilities

- (void) dispStatus {
    _volumeSlider.value = volume;
    _frequencySlider.value = frequency;
    _statusLabel.text = [NSString stringWithFormat:@"Freq: %6.1fHz, Vol: %4.1f%%", frequency, volume];
}

- (void) setPanOffset {
    offsetPanWidth = _innerView.frame.size.width;
    offsetPanHeight = _innerView.frame.size.height;
    view_x = view_y = 0;
}

@end
