//
//  ViewController.h
//  Theremin-iOS
//
//  Created by Bill Weinman on 2014-08-14.
//  Copyright (c) 2014 Bill Weinman. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AudioUnit/AudioUnit.h>
#import <AVFoundation/AVFoundation.h>

const static double _timerValue = .025;

@interface ViewController : UIViewController <UIGestureRecognizerDelegate> {
    
@public
    double frequency;
    double volume;
    double sampleRate;
    double theta;
}

@end

